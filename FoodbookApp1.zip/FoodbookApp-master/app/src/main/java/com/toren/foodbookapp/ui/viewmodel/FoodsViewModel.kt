package com.toren.foodbookapp.ui.viewmodel

import androidx.lifecycle.ViewModel

class FoodsViewModel : ViewModel() {

}